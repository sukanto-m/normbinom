from setuptools import setup

setup(name='normbinom',
      version='0.1',
      description='Gaussian & Binomial distributions',
      packages=['normbinom'],
      author = 'Sukanto Mukherjee',
      author_email = 'readrunner@protonmail.com',
      zip_safe=False)
